#include "CompanyRepository.hpp"

#include "storage/SqlQuery.hpp"

#include <QDateTime>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QUuid>

#include <stdexcept>

namespace {

const QString companySelectProjection = QStringLiteral(
    "SELECT id, display_name, created_at, updated_at ");

QString normalizedCompanyName(const QString& name)
{
    return name.trimmed().toCaseFolded();
}

Company companyFromQuery(const QSqlQuery& query)
{
    Company company;
    company.id_ = query.value(QStringLiteral("id")).toString();
    company.name_ = query.value(QStringLiteral("display_name")).toString();
    company.createdAt_ = storage::sql::readIsoDateTime(
        query,
        QStringLiteral("created_at"));
    company.updatedAt_ = storage::sql::readIsoDateTime(
        query,
        QStringLiteral("updated_at"));
    return company;
}

}

CompanyRepository::CompanyRepository(QSqlDatabase& database)
    : database_(database)
{
}

QVector<Company> CompanyRepository::findAll() const
{
    QSqlQuery query{database_};
    if (!query.exec(
            companySelectProjection
            + QStringLiteral("FROM companies ORDER BY normalized_name"))) {
        storage::sql::throwQueryError(query, QStringLiteral("load companies"));
    }

    QVector<Company> companies;
    while (query.next()) {
        companies.append(companyFromQuery(query));
    }
    return companies;
}

Company CompanyRepository::findOrCreateByName(const QString& name) const
{
    const auto displayName = name.trimmed();
    const auto normalizedName = normalizedCompanyName(displayName);
    if (normalizedName.isEmpty()) {
        throw std::invalid_argument("Company name must not be blank.");
    }

    QSqlQuery findQuery{database_};
    findQuery.prepare(
        companySelectProjection
        + QStringLiteral("FROM companies WHERE normalized_name = ?"));
    findQuery.addBindValue(normalizedName);
    storage::sql::execute(
        findQuery,
        QStringLiteral("find a company by normalized name"));
    if (findQuery.next()) {
        return companyFromQuery(findQuery);
    }

    const auto now = QDateTime::currentDateTimeUtc();
    Company company;
    company.id_ = QUuid::createUuid().toString(QUuid::WithoutBraces);
    company.name_ = displayName;
    company.createdAt_ = now;
    company.updatedAt_ = now;

    QSqlQuery insertQuery{database_};
    insertQuery.prepare(QStringLiteral(
        "INSERT INTO companies (id, display_name, normalized_name, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, ?)"));
    insertQuery.addBindValue(company.id_);
    insertQuery.addBindValue(company.name_);
    insertQuery.addBindValue(normalizedName);
    insertQuery.addBindValue(now.toString(Qt::ISODateWithMs));
    insertQuery.addBindValue(now.toString(Qt::ISODateWithMs));
    storage::sql::execute(insertQuery, QStringLiteral("insert a company"));

    return company;
}
