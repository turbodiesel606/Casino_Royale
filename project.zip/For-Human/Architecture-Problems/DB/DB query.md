# DB Query transaction reduntance
opening new transaction is reduntant for single query... 
we do only one operation(DELETE).
query without SqlTransaction for single query while do refactor.