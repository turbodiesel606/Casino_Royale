# Database Schema Migration

## Future architectural improvement

The current step-by-step migration strategy can be replaced with direct migrations from any supported older schema version to the latest schema version. 
A direct migration must still correctly transform and preserve all existing data.

For example: migrate directly from version 1 to version 3, 4, 5, etc, 
rather than version first to version 2 and then to version 3, and then etc...