﻿# Uncomplete UpdateJob risk.

While a lot of CV and jobs are being added, UpdateJob may not get its turn before the application closes.

## Me:
what are the cancellation checks needed for? they needed only for appplication close status while Job, cv are adding/updating? 
Consider a scenario where the user simultaneously adds 100 Jobs and CVs, updates Job+performs "Change CV" operation, 
then user try to close program while these 4 functionality are still working simultaneously. What will happen when user try to close program at this time? READONLY
## Codex:

No. The pending counters determine whether closing is blocked. Cancellation checks make “Interrupt and Exit” actually stop active work at safe points.
At the QML level, the bulk-cancellation functions are currently called only by the close dialog ([Main.qml (line 175)](D:/Project_CV/Root/qml/Main.qml:175)). They also support worker shutdown and prevent stale outcomes from being accepted.
Your 100 Jobs + 100 CVs scenario
These are not four simultaneously executing backend operations:
- The 100 Add Jobs and one Update Job share one FIFO. Only one create or update executes at a time ([JobApplicationsController.cpp (line 429)](D:/Project_CV/Root/src/jobs/JobApplicationsController.cpp:429)).
- “Change CV” is part of the same Update Job request; selecting the file merely stores its URL in QML until Save Changes is submitted ([JobDescriptionPane.qml (line 162)](D:/Project_CV/Root/qml/pages/JobDescriptionPane.qml:162), [JobDescriptionPane.qml (line 295)](D:/Project_CV/Root/qml/pages/JobDescriptionPane.qml:295)).
- The 100 standalone Add CV requests use another FIFO, again with only one active import ([CvLibraryController.cpp (line 540)](D:/Project_CV/Root/src/cvs/CvLibraryController.cpp:540)).
- Therefore, at most two worker operations execute concurrently: one job save/update and one standalone CV import.
- Their file buffering can overlap, but their CV persistence sections are serialized by the shared lock ([CvLockWrapper.hpp (line 12)](D:/Project_CV/Root/src/cvs/CvLockWrapper.hpp:12)).
Assuming 100 of each plus one update-with-replacement, the maximum pending count is approximately 201—not 202—because Update Job and Change CV are one operation.
What happens when the user closes
There is an important ordering detail.
If the update has already been submitted—even if it is merely waiting behind 100 Add Jobs—jobUpdateInProgress is true. The first close request is rejected and stored as a deferred protected action ([Main.qml (line 186)](D:/Project_CV/Root/qml/Main.qml:186)).
Consequently:
1. The user does not immediately get “Interrupt and Exit”.
2. The job FIFO continues processing.
3. If the update was submitted after the 100 jobs, all 100 preceding jobs must finish before the update starts.
4. Standalone CV imports continue concurrently.
5. If the update succeeds, QML automatically tries closing again ([Main.qml (line 229)](D:/Project_CV/Root/qml/Main.qml:229)).
6. If the update fails, the deferred close is discarded and the application remains open. The user must close again.
On that subsequent close, if work remains, the “Work in progress” dialog appears:
- Wait: work continues. The application does not automatically exit when it finishes; the dialog closes and the app remains open.
- Interrupt and Exit: queued work is removed, active cancellation is requested, and the window remains open until every pending count reaches zero ([Main.qml (line 158)](D:/Project_CV/Root/qml/Main.qml:158), [Main.qml (line 175)](D:/Project_CV/Root/qml/Main.qml:175)).
If Change CV was selected but Save Changes was not submitted, it is only unsaved UI state. Closing first shows the Unsaved changes dialog: Save, Don’t Save, or Cancel.
What cancellation checks do
Active operation state	Behaviour after Interrupt
Waiting in one of the FIFOs	Removed immediately; it never executes.
Reading/buffering a CV	Cancellation is checked between 1 MiB reads, so processing stops cooperatively ([CvManagedFileStore.cpp (line 109)](D:/Project_CV/Root/src/cvs/CvManagedFileStore.cpp:109)).
Waiting for the shared CV lock	The current plain std::mutex wait cannot itself be cancelled. It must wait for the lock owner, then checks cancellation.
Before transaction/persistence	Add Job, Update-with-CV, and Add CV check again and can return without mutation ([AddJobService.cpp (line 90)](D:/Project_CV/Root/src/jobs/AddJobService.cpp:90), [UpdateJobService.cpp (line 99)](D:/Project_CV/Root/src/jobs/UpdateJobService.cpp:99), [CvImportExecutor.cpp (line 93)](D:/Project_CV/Root/src/cvs/CvImportExecutor.cpp:93)).
After the last effective check	The current operation can still finish and commit.
After final file rename	It should finish the transaction or roll back and compensate; forcibly abandoning it could leave the file and database inconsistent.


Therefore, after “Interrupt and Exit”:
- The roughly 99 waiting Jobs and 99 waiting CVs are discarded.
- Each currently active request may either cancel or complete, depending on how far it progressed.
- A successfully completed active request remains committed even though the user selected Interrupt.
- Exit happens only after both active outcomes return and the pending counters become zero.
- There is no forced thread termination or close timeout. A blocked filesystem/SQL operation can delay closing. Worker shutdown ultimately joins the worker threads rather than terminating them ([SingleActiveWorkerRuntime.cpp (line 97)](D:/Project_CV/Root/src/common/SingleActiveWorkerRuntime.cpp:97)).
Current-worktree cancellation gaps
The live worktree is presently inconsistent with the documented cancellation design:
- The cancellable FIFO CvMutationQueue has been replaced locally by a plain, non-FIFO, non-cancellable mutex wrapper.
- Cancellation before staging, during .part writing, and immediately before final rename is compiled out with #if 0 ([CvManagedFileStore.cpp (line 200)](D:/Project_CV/Root/src/cvs/CvManagedFileStore.cpp:200)).
- The service-level pre-import check is also compiled out ([CvImportService.cpp (line 73)](D:/Project_CV/Root/src/cvs/CvImportService.cpp:73)).
- Consequently, cancellation received after the outer post-lock check can be ignored while staging, renaming, and committing. “Interrupt” may therefore take longer and may still commit the active operation.
- Metadata-only updates currently acquire the CV mutex too ([UpdateJobService.cpp (line 104)](D:/Project_CV/Root/src/jobs/UpdateJobService.cpp:104)), contrary to the architecture document and corresponding test expectation.
- Tests still include the missing cvs/CvMutationQueue.hpp, while CMake registers CvLockWrapper.hpp for that test target ([CvMutationQueueTest.cpp (line 1)](D:/Project_CV/Root/tests/cvs/CvMutationQueueTest.cpp:1), [CMakeLists.txt (line 480)](D:/Project_CV/Root/CMakeLists.txt:480)). The test-enabled worktree should therefore be expected not to compile in its current state.
The cancellation checks worth retaining are: worker-entry, during large buffering, after acquiring a blocking lock, before durable mutation, during .part writing, and immediately before final rename. After rename, completing or compensating the transaction is the safer behaviour.
This was read-only static inspection. No files were changed, and no build, CTest, or GUI scenario was run.

## Me:
List all possible scenarios in which the program closes while the following three features are active simultaneously: add 100 resumes, add 100 jobs, and "Change CV". READONLY

## Codex:

There are zero normal UI scenarios where the program actually terminates while all three features remain active. A close request can occur while they are pending, but Main.qml rejects it and follows the paths below.
Also, the three features are not three simultaneous persistence operations:
- 100 resumes use one FIFO: at most one import executes.
- 100 Add Jobs and “Change CV” share the same Job Save FIFO: at most one Add Job or one Change CV update executes.
- Both workers share one mutex, so only one of them persists CV/database changes at a time.
- If all 100 jobs are queued before Change CV, Change CV is job-save operation 101. Initial maximum is therefore 101 job saves + 100 imports = 201 pending operations. [JobApplicationsController.cpp (line 417)](/D:/Project_CV/Root/src/jobs/JobApplicationsController.cpp:417), [SerialOperationQueue.hpp (line 63)](/D:/Project_CV/Root/src/common/SerialOperationQueue.hpp:63)
Complete normal-close scenarios
1. Replacement CV selected, but “Save Changes” not submitted
   “Change CV” is only unsaved QML state; no backend update exists yet. [JobDescriptionPane.qml (line 295)](/D:/Project_CV/Root/qml/pages/JobDescriptionPane.qml:295)
   Closing opens the Unsaved Changes dialog:
   - Cancel: program stays open; job and resume queues continue.
   - Don’t Save: Change CV is discarded; closing is retried and the Work in Progress dialog appears for the remaining jobs/resumes.
   - Save: Change CV is submitted into the Job Save FIFO.
     - If rejected by validation/admission, the close request is abandoned.
     - If accepted, closing is deferred until that update finishes.
2. Change CV is queued behind Add Jobs
   Closing is rejected silently and remembered. No Work in Progress dialog appears, and no cancellation is requested. Repeated close attempts do nothing while the deferred action exists. [Main.qml (line 66)](/D:/Project_CV/Root/qml/Main.qml:66)
   With the exact order “100 Add Jobs, then Change CV,” all 100 jobs must finish before Change CV starts.
3. Change CV is actively buffering or waiting for the shared mutex
   The result is the same: the application remains open and the update continues. Waiting on std::mutex itself is not cancellation-aware.
4. Change CV has begun persistence
   It runs through success or failure. The close request does not interrupt it. Once the final post-lock cancellation check is passed, file staging, SQL work, commit/rollback, and cleanup continue. [UpdateJobService.cpp (line 104)](/D:/Project_CV/Root/src/jobs/UpdateJobService.cpp:104)
5. Change CV succeeds
   The deferred close is retried. [Main.qml (line 229)](/D:/Project_CV/Root/qml/Main.qml:229)
   - If no jobs or resumes remain, the program closes immediately.
   - If anything remains, the Work in Progress dialog appears.
   - In the exact “100 jobs first, Change CV last” ordering, all jobs are already finished; normally only resume imports can remain.
6. Change CV fails
   The deferred close request is cleared and the program stays open. The edit and selected replacement remain available for correction.
   A later close attempt returns to the Unsaved Changes dialog, where the user can retry Save, discard, or cancel.
7. Work in Progress → Wait
   Work continues, but the application does not automatically exit:
   - Clicking Wait dismisses the dialog and leaves the program open.
   - Leaving the dialog visible until everything finishes also only dismisses the dialog.
   - The user must request close again afterward. [Main.qml (line 158)](/D:/Project_CV/Root/qml/Main.qml:158)
8. Work in Progress → Interrupt and Exit
   The application:
   - Deletes all waiting Job Save and resume-import requests.
   - Requests cooperative cancellation of the one active Job Save and one active resume import.
   - Waits for both active workers to return.
   - Closes only when the pending count reaches zero. [Main.qml (line 175)](/D:/Project_CV/Root/qml/Main.qml:175), [SerialOperationQueue.hpp (line 101)](/D:/Project_CV/Root/src/common/SerialOperationQueue.hpp:101)
   Each in-flight job/resume can ultimately be:
   - canceled before persistence;
   - completed successfully because cancellation arrived too late;
   - failed and rolled back.
   Therefore, when both queues have an in-flight operation, the nine logical outcome pairs are:
   1. both canceled;
   2. job canceled, resume succeeds;
   3. job canceled, resume fails;
   4. job succeeds, resume canceled;
   5. both succeed;
   6. job succeeds, resume fails;
   7. job fails, resume canceled;
   8. job fails, resume succeeds;
   9. both fail.
   Already completed work remains committed. In every finite case, the application closes after both active results are handled. If a worker hangs permanently, the application never closes; there is no timeout or forced worker termination.
Important current-worktree delay
The current modified source sleeps for 10 seconds after every successful standalone resume commit, while still holding the shared mutex. [CvImportExecutor.cpp (line 100)](/D:/Project_CV/Root/src/cvs/CvImportExecutor.cpp:100)
Consequences if this source is compiled:
- 100 successful resume imports contain at least 1,000 seconds—about 16 minutes 40 seconds—of sleep alone.
- Change CV and Add Job persistence can be blocked behind the current sleeping resume import.
- “Interrupt and Exit” during that post-commit sleep cannot cancel that import; closing waits for the remaining sleep and its completion result.
Forced termination
A forced process kill, crash, or power loss is the only way the process can genuinely terminate while all three features are still pending:
- Waiting requests are lost because they exist only in memory.
- Work still in buffering normally creates no durable result.
- An uncommitted SQL transaction depends on SQLite crash recovery.
- Stale .part files are removed at startup, and finalized files without database records are quarantined. [CvManagedFileStore.cpp (line 312)](/D:/Project_CV/Root/src/cvs/CvManagedFileStore.cpp:312)
- Already committed work remains.
Normal worker shutdown is cooperative and joins the worker thread; it does not force-terminate it. [SingleActiveWorkerRuntime.cpp (line 97)](/D:/Project_CV/Root/src/common/SingleActiveWorkerRuntime.cpp:97)
This was a static, read-only inspection of the current dirty worktree. No files were changed, and no build, CTest, or GUI execution was performed. Therefore, this describes the current source, not necessarily the last-built executable.
If the desired behavior is to offer Interrupt and Exit immediately while Change CV is queued or running, the QML close-state ordering must change; adding more cancellation checks alone will not produce that UI behavior.